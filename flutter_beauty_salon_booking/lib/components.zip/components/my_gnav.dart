// import 'package:flutter/material.dart';
// import 'package:flutter/widgets.dart';
// import 'package:google_nav_bar/google_nav_bar.dart';

// class MyGNav extends StatelessWidget {
//   IconData icon;
//   String text;
//    MyGNav({super.key,required this.icon,required this.text});

//   @override
//   Widget build(BuildContext context) {
//     return 
    
    
//     //  GNav(tabs: [
//     //   GButton(
//     //   icon: icon,
//     //   text: text,)
//     //   ],);
//   }
// }