import 'package:flutter/widgets.dart';

class Service{
  String id;
  String name;
  String description;
  double price;
  int duration;
  String photo;
  Service({required this.id,required this.name,required this.description,required this.duration,required this.photo,required this.price});

  
}